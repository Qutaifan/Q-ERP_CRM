This template has been developed by DoliCloud (https://www.dolicloud.com) for Dolibarr ERP CRM.
